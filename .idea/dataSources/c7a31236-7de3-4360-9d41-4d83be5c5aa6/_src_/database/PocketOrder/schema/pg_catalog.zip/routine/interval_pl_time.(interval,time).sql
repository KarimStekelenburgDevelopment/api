CREATE FUNCTION interval_pl_time (interval, time without time zone) RETURNS time without time zone
	LANGUAGE sql
AS $$
select $2 + $1
$$
