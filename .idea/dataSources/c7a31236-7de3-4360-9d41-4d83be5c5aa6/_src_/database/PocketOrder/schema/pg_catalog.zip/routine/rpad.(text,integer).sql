CREATE FUNCTION rpad (text, integer) RETURNS text
	LANGUAGE sql
AS $$
select pg_catalog.rpad($1, $2, ' ')
$$
