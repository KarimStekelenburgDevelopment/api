CREATE FUNCTION time (abstime) RETURNS time without time zone
	LANGUAGE sql
AS $$
select cast(cast($1 as timestamp without time zone) as pg_catalog.time)
$$
