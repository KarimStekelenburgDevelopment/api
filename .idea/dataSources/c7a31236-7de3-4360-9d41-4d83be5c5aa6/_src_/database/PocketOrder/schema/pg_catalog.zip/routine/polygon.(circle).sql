CREATE FUNCTION polygon (circle) RETURNS polygon
	LANGUAGE sql
AS $$
select pg_catalog.polygon(12, $1)
$$
